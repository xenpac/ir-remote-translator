Windows compiler install:

Install avr-gcc5.3.0.exe.
It will default to c:\SysGCC\
It will add the path to PATH.
Then extract the 2 files from avrdude-6.3-mingw32.zip and copy them to:
c:\SysGCC\avr\bin

You need a USBASP programing device (cheap on aliexpress) to flash your hex-file.